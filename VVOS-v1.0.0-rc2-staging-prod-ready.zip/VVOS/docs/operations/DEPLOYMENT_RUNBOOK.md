# VVOS deployment runbook

## Normale wijziging
1. Maak `feature/<korte-naam>` vanaf `staging`.
2. Wijzig code.
3. Run `npm run check`.
4. Open PR naar `staging`.
5. CI moet groen zijn.
6. Merge naar `staging`.
7. Firebase App Hosting staging rolt automatisch uit.
8. Mik beoordeelt de staging URL.
9. Bij akkoord: open PR `staging -> main` zonder extra wijzigingen.
10. Merge alleen met groene CI.
11. Trigger in Firebase Production een handmatige rollout van exact de goedgekeurde commit.
12. Controleer `/api/health`, homepage, login en kernroutes.
13. Tag release: `vX.Y.Z`.

## Belangrijk
Nooit ontwikkelen in `main`. Nooit productie-secrets in GitHub committen. Nooit productie deployen met een andere commit dan de op staging goedgekeurde commit.
