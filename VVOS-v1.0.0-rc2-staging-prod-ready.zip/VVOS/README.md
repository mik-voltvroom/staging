# VVOS — Volt & Vroom Operating System

VVOS is het geïntegreerde digitale bedrijfsplatform van **Volt & Vroom**. De repository combineert de publieke website met voorraadbeheer, CRM, verkoopautomatisering, deals, aflevering, klantportaal, werkplaats, garantie en financiële sturing.

## Modules

| Domein | Functionaliteit |
|---|---|
| Website | Homepage, voorraad en voertuigdetailpagina’s |
| Operations | Voertuigen, foto’s, publicatiecontrole en marges |
| Integraties | Firebase, RDW, VWE, Google Merchant en cronjobs |
| Sales | Leads, scoring, afspraken, offertes en inruil |
| Deal & Delivery | Contracten, betalingen, garantie, aflevering en klantportaal |
| Workshop | Werkorders, inspecties, onderdelen, uren en garantieclaims |
| Finance | Facturen, kasstromen, voorraadfinanciering en management control |

## Snel starten

```bash
cp .env.example .env.local
npm ci
npm run dev
```

Open daarna `http://localhost:3000`.

## Controle

```bash
npm run typecheck
npm run test
npm run build
```

Of gezamenlijk:

```bash
npm run check
```

## Belangrijkste routes

- `/` — publieke Volt & Vroom-website
- `/dashboard` — intern command center
- `/dashboard/voorraad` — voorraadbeheer
- `/dashboard/leads` — CRM en salespipeline
- `/dashboard/afleveringen` — afleverplanning
- `/dashboard/werkplaats` — werkplaatsplanning
- `/dashboard/finance` — financiële cockpit
- `/dashboard/management` — management control
- `/api/merchant-feed` — XML-voertuigfeed

## Modi

VVOS ondersteunt een testbare demo-opzet en een Firebase-productiepad. Externe acties mogen zonder geldige credentials uitsluitend een expliciete preview- of sandboxrespons geven.

## Documentatie

- `docs/ARCHITECTURE.md`
- `docs/DATA_MODEL.md`
- `docs/WORKFLOWS.md`
- `docs/BUILD_LAYER_02.md` t/m `BUILD_LAYER_07.md`
- `docs/operations/PRODUCTION_CHECKLIST.md`
- `AGENTS.md`
- `SECURITY.md`
- `ROADMAP.md`

## Merk

De interface volgt de Volt & Vroom-richting: minimalistisch, modern, premium, veel witruimte, verfijnde typografie en zachte ijsblauwe accenten.

## Status

Versie `1.0.0-rc.1` is de eerste release candidate. Audit, typecontrole en 7 regressietests zijn groen; de lokale runtime-smoketest retourneert HTTP 200 voor de homepage en healthcheck. Livegang vereist nog echte provideraccounts, Firebase-productieconfiguratie, fiscale controle en acceptatietesten met eigen data.

## Deployment: staging + production
VVOS gebruikt voorlopig twee Firebase App Hosting omgevingen:

- `staging` branch -> Firebase Staging -> automatische rollout
- `main` branch -> Firebase Production -> alleen handmatige rollout na expliciet akkoord van Mik

Zie `docs/operations/STAGING_PRODUCTION_SETUP.md` en `docs/operations/DEPLOYMENT_RUNBOOK.md`.
