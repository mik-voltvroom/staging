import { NextRequest, NextResponse } from "next/server";
export function middleware(request: NextRequest) {
  const productionAuth = process.env.VVOS_REQUIRE_AUTH === "true";
  if (!productionAuth) return NextResponse.next();
  if (!request.cookies.get("vvos_session")) return NextResponse.redirect(new URL("/login", request.url));
  return NextResponse.next();
}
export const config = { matcher: ["/dashboard/:path*"] };
