import fs from "node:fs";

const requiredForProduction = [
  "NEXT_PUBLIC_SITE_URL",
  "NEXT_PUBLIC_FIREBASE_API_KEY",
  "NEXT_PUBLIC_FIREBASE_PROJECT_ID",
  "NEXT_PUBLIC_FIREBASE_APP_ID",
  "FIREBASE_ADMIN_PROJECT_ID",
  "FIREBASE_ADMIN_CLIENT_EMAIL",
  "FIREBASE_ADMIN_PRIVATE_KEY",
  "CRON_SECRET",
  "PORTAL_TOKEN_SECRET",
  "AUDIT_HASH_SALT",
];

const missing = requiredForProduction.filter((key) => !process.env[key] || String(process.env[key]).includes("replace-with"));
const unsafe = [];
if (process.env.VVOS_DATA_MODE !== "firebase") unsafe.push("VVOS_DATA_MODE moet firebase zijn");
if (process.env.VVOS_REQUIRE_AUTH !== "true") unsafe.push("VVOS_REQUIRE_AUTH moet true zijn");
if (process.env.NODE_ENV !== "production") unsafe.push("NODE_ENV is niet production");

const result = {
  ready: missing.length === 0 && unsafe.length === 0,
  missing,
  unsafe,
  checkedAt: new Date().toISOString(),
};
console.log(JSON.stringify(result, null, 2));
if (!result.ready) process.exitCode = 1;
