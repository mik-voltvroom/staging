import { NextResponse } from "next/server";
export async function GET(request: Request) {
  if (process.env.CRON_SECRET && request.headers.get("authorization") !== `Bearer ${process.env.CRON_SECRET}`) return NextResponse.json({ error: "Niet geautoriseerd" }, { status: 401 });
  return NextResponse.json({ ok: true, ranAt: new Date().toISOString(), jobs: ["validate_inventory", "refresh_merchant_feed", "flag_stale_leads"], note: "Cron orchestration gereed; providers worden geactiveerd via env-configuratie." });
}
