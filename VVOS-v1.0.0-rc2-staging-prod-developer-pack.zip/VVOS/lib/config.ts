function hasJsonEnv(name: string): boolean {
  const value = process.env[name];
  if (!value) return false;
  try {
    JSON.parse(value);
    return true;
  } catch {
    return false;
  }
}

export const hasAppHostingWebConfig = hasJsonEnv("FIREBASE_WEBAPP_CONFIG");
export const hasAppHostingAdminConfig = hasJsonEnv("FIREBASE_CONFIG") || Boolean(process.env.GOOGLE_CLOUD_PROJECT);

export const hasExplicitFirebaseClientConfig = Boolean(
  process.env.NEXT_PUBLIC_FIREBASE_API_KEY &&
  process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID &&
  process.env.NEXT_PUBLIC_FIREBASE_APP_ID
);

export const hasExplicitFirebaseAdminConfig = Boolean(
  process.env.FIREBASE_ADMIN_PROJECT_ID &&
  process.env.FIREBASE_ADMIN_CLIENT_EMAIL &&
  process.env.FIREBASE_ADMIN_PRIVATE_KEY
);

export const isFirebaseClientConfigured = hasAppHostingWebConfig || hasExplicitFirebaseClientConfig;
export const isFirebaseAdminConfigured = hasAppHostingAdminConfig || hasExplicitFirebaseAdminConfig;

export const integrationMode = process.env.VVOS_DATA_MODE === "firebase" ? "firebase" : "demo";
export const vvosEnvironment = process.env.VVOS_ENVIRONMENT || "local";
