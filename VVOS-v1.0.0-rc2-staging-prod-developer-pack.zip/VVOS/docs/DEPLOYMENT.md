# VVOS Staging + Production deployment

## Doel

VVOS gebruikt voorlopig twee echte Firebase-omgevingen:

- **staging** — automatisch uitrollen vanaf Git branch `staging`.
- **production** — alleen uitrollen na expliciete goedkeuring van Mik, op exact dezelfde commit die op staging is geaccepteerd.

Lokale ontwikkeling en feature branches zijn geen aparte Firebase-omgeving.

## Branchmodel

```text
feature/* -> Pull Request -> staging -> acceptatie -> main / productie
```

Rechtstreeks committen op `main` of rechtstreeks wijzigen in Firebase Production is niet toegestaan.

## Firebase-projecten

Maak twee losse Firebase-projecten aan:

- `volt-vroom-staging` (of beschikbare variant)
- `volt-vroom-prod` (of beschikbare variant)

Gebruik voor beide **Firebase App Hosting** en verbind dezelfde GitHub-repository.

### Staging backend

- Live branch: `staging`
- Automatic rollouts: **ON**
- Environment name: `staging`
- App root: `/` zolang `package.json` in de repository-root staat
- Custom domain: `staging.voltvroom.nl` zodra DNS beschikbaar is

App Hosting leest dan `apphosting.staging.yaml` bovenop `apphosting.yaml`.

### Production backend

- Live branch: `main`
- Automatic rollouts: **OFF**
- Environment name: `production`
- App root: `/`
- Custom domain: `www.voltvroom.nl`

App Hosting leest dan `apphosting.production.yaml` bovenop `apphosting.yaml`.

## Vereiste secrets per Firebase-project

Maak deze secrets afzonderlijk aan in staging en production:

- `VVOS_CRON_SECRET`
- `VVOS_PORTAL_TOKEN_SECRET`
- `VVOS_AUDIT_HASH_SALT`

Gebruik bij voorkeur `firebase apphosting:secrets:set` of Cloud Secret Manager. De waarden worden nooit in GitHub of `.env` gecommit.

Later kunnen providersecrets per omgeving worden toegevoegd, bijvoorbeeld RDW, VWE, WhatsApp, e-mail en betaalproviders.

## Firebase SDK

Op App Hosting gebruikt VVOS de automatisch geïnjecteerde Firebase-configuratie:

- Web SDK via `FIREBASE_WEBAPP_CONFIG`
- Admin SDK via `FIREBASE_CONFIG` en Application Default Credentials

Daarom zijn service-account private keys niet nodig in de App Hosting runtime.

## Releaseproces

1. Wijziging op `feature/...`.
2. Pull Request naar `staging`.
3. GitHub CI moet groen zijn.
4. Merge naar `staging`.
5. Firebase Staging rolt automatisch uit.
6. Mik/Alexander testen staging.
7. Noteer de geaccepteerde commit SHA.
8. Merge/promoveer exact die code naar `main`.
9. Start Production workflow met exact die commit SHA.
10. Na production approval: maak in Firebase Production een handmatige rollout van exact die commit.
11. Voer smoke check uit tegen `https://www.voltvroom.nl`.

De laatste Firebase-rollout is voorlopig bewust een expliciete stap. Zodra GitHub en Firebase zijn aangemaakt testen we keyless CI-authenticatie en automatiseren we die handoff pas als die bewezen betrouwbaar is.

## Smoke check

```bash
SMOKE_URL=https://staging.voltvroom.nl npm run smoke
SMOKE_URL=https://www.voltvroom.nl npm run smoke
```

## Rollback

Bij een kritieke fout:

1. Firebase Console -> App Hosting -> Production -> Rollouts.
2. Kies de vorige bekende goede rollout.
3. Gebruik **Roll back to this build** voor een onmiddellijke rollback.
4. Open daarna een fix-PR; wijzig nooit rechtstreeks productiecode.
