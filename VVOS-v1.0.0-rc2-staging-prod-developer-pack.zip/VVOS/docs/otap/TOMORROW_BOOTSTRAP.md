# Morgen: bootstrap zodra @voltvroom.nl beschikbaar is

## 1. GitHub

1. Maak het zakelijke GitHub-account aan met het Volt & Vroom e-mailadres.
2. Maak GitHub Organization `volt-vroom` (of beschikbare naam).
3. Maak private repository `vvos`.
4. Push deze repository naar GitHub.
5. Maak branches `main` en `staging`.
6. Bescherm `main`: geen directe pushes; PR vereist; CI vereist.
7. Bescherm `staging`: CI vereist vóór merge.
8. Maak GitHub Environment `production`; configureer Mik als vereiste reviewer als het gekozen GitHub-plan dit ondersteunt. Zo niet: houd Firebase Production handmatige rollout als harde goedkeuringsstap.

## 2. Firebase Staging

1. Maak apart Firebase-project.
2. Activeer billing/Blaze voor App Hosting indien Firebase dit vraagt.
3. Activeer Authentication, Firestore en Storage.
4. Maak App Hosting backend.
5. Verbind GitHub `volt-vroom/vvos`.
6. Live branch `staging`.
7. Automatic rollouts ON.
8. Environment name `staging`.
9. Maak secrets uit `docs/DEPLOYMENT.md`.
10. Deploy eerste staging-versie.
11. Test `/api/health` en dashboard-login.

## 3. Firebase Production

1. Maak tweede, los Firebase-project en markeer dit als production environment.
2. Activeer Authentication, Firestore en Storage.
3. Maak App Hosting backend.
4. Verbind dezelfde GitHub-repository.
5. Live branch `main`.
6. Automatic rollouts OFF.
7. Environment name `production`.
8. Maak afzonderlijke production secrets.
9. Koppel pas na staging-validatie `www.voltvroom.nl`.
10. Voer eerste productie-rollout handmatig uit met de geaccepteerde commit.

## 4. Daarna

- echte medewerkers en rollen toevoegen;
- Firestore/Storage rules deployen en testen;
- demo-data uitsluitend in staging;
- VWE/RDW/Merchant koppelingen per omgeving activeren;
- GitHub-to-Firebase productieautomatisering pas inschakelen na een geslaagde end-to-end test.
