# VVOS 1.0.0-rc.2-otap

## Klaargezet op 12 augustus 2026

- staging + production architectuur toegevoegd;
- Firebase App Hosting environment-configs toegevoegd;
- staging auto-rollout model gedocumenteerd;
- production approval gate voorbereid;
- Firebase SDK aangepast voor App Hosting default configuration / ADC;
- oude Caroutlet e-mailreferenties uit actieve code en security-documentatie verwijderd;
- SALES_DEFAULT_OWNER gewijzigd naar mik@voltvroom.nl;
- repository guard toegevoegd tegen oude domeinen en secrets-bestanden;
- CI workflow toegevoegd;
- production promotion workflow toegevoegd;
- smoke check en production-readiness check toegevoegd;
- bootstrapchecklist voor GitHub/Firebase toegevoegd;
- secrets matrix toegevoegd;
- ChatGPT/Codex change flow vastgelegd;
- ADR voor twee omgevingen toegevoegd.

## Nog bewust niet geactiveerd

- echte Firebase project IDs;
- echte GitHub repository/branch protection;
- echte App Hosting backends;
- providersecrets;
- volledig automatische productie-rollout vanuit GitHub.

De productie-rollout wordt pas geautomatiseerd nadat de zakelijke accounts bestaan en de authenticatie end-to-end is getest. Tot dat moment is de expliciete Firebase Production rollout de laatste veiligheidsstap.
