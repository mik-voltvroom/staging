# ADR-001 — Twee omgevingen: staging + production

**Status:** accepted

## Besluit

Volt & Vroom gebruikt voorlopig twee cloudomgevingen: staging en production. Lokale development en feature branches bestaan uitsluitend in Git/GitHub en krijgen geen apart Firebase-project.

## Waarom

- eenvoudiger beheer tijdens de startfase;
- volledige isolatie van echte klant-/voertuigdata;
- snel automatisch staging-feedback;
- expliciete menselijke controle vóór productie;
- eenvoudig later uitbreidbaar naar een volledige OTAP-straat.

## Niet toegestaan

- één Firestore-database delen tussen staging en production;
- productie als testomgeving gebruiken;
- secrets delen tussen omgevingen;
- wijzigingen rechtstreeks in productie uitvoeren buiten de releaseflow.
