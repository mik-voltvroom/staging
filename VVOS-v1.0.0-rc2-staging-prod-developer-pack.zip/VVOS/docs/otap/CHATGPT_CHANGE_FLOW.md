# Mik -> ChatGPT/Codex -> staging -> production

Gewenste toekomstige werkwijze:

1. Mik beschrijft de wijziging in natuurlijke taal.
2. ChatGPT/Codex werkt in een feature branch.
3. Agent voert `npm run check:ci` uit.
4. Pull Request naar `staging`.
5. Na merge rolt Firebase Staging automatisch uit.
6. Mik controleert staging.
7. Mik zegt expliciet: **akkoord voor productie**.
8. Alleen de exact geaccepteerde commit mag worden gepromoveerd.
9. Production rollout start na goedkeuringsgate.
10. Automatische smoke check en rollbackmogelijkheid blijven verplicht.

## AI-regels

ChatGPT/Codex mag nooit:

- rechtstreeks productiegegevens aanpassen;
- secrets in code plaatsen;
- production zonder expliciete Mik-goedkeuring deployen;
- security rules versoepelen zonder de wijziging expliciet te melden;
- demo-data als echte data publiceren.
