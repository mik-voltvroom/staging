# Secrets matrix

| Secret | Staging | Production | GitHub? | Opmerking |
|---|---|---|---|---|
| VVOS_CRON_SECRET | eigen waarde | eigen waarde | nee | server-only |
| VVOS_PORTAL_TOKEN_SECRET | eigen waarde | eigen waarde | nee | server-only |
| VVOS_AUDIT_HASH_SALT | eigen waarde | eigen waarde | nee | server-only |
| RDW_API_KEY | test indien beschikbaar | productie | nee | later |
| VWE_WEBHOOK_SECRET | test | productie | nee | later |
| WHATSAPP_TOKEN | sandbox/test | productie | nee | later |
| EMAIL_API_KEY | test | productie | nee | later |
| MOLLIE_API_KEY | test | live | nee | later |

**Nooit dezelfde secretwaarde hergebruiken tussen staging en production.**
