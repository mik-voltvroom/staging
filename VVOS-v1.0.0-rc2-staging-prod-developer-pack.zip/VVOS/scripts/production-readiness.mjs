function hasJsonEnv(name) {
  const value = process.env[name];
  if (!value) return false;
  try { JSON.parse(value); return true; } catch { return false; }
}

const environment = process.env.VVOS_ENVIRONMENT;
const firebaseClientConfigured = hasJsonEnv("FIREBASE_WEBAPP_CONFIG") || Boolean(
  process.env.NEXT_PUBLIC_FIREBASE_API_KEY && process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID && process.env.NEXT_PUBLIC_FIREBASE_APP_ID
);
const firebaseAdminConfigured = hasJsonEnv("FIREBASE_CONFIG") || Boolean(process.env.GOOGLE_CLOUD_PROJECT) || Boolean(
  process.env.FIREBASE_ADMIN_PROJECT_ID && process.env.FIREBASE_ADMIN_CLIENT_EMAIL && process.env.FIREBASE_ADMIN_PRIVATE_KEY
);

const required = ["NEXT_PUBLIC_SITE_URL", "CRON_SECRET", "PORTAL_TOKEN_SECRET", "AUDIT_HASH_SALT"];
const missing = required.filter((key) => !process.env[key] || String(process.env[key]).includes("replace-with"));
const unsafe = [];

if (!["staging", "production"].includes(environment)) unsafe.push("VVOS_ENVIRONMENT moet staging of production zijn");
if (process.env.VVOS_DATA_MODE !== "firebase") unsafe.push("VVOS_DATA_MODE moet firebase zijn");
if (process.env.VVOS_REQUIRE_AUTH !== "true") unsafe.push("VVOS_REQUIRE_AUTH moet true zijn");
if (!firebaseClientConfigured) unsafe.push("Firebase Web SDK configuratie ontbreekt");
if (!firebaseAdminConfigured) unsafe.push("Firebase Admin/App Hosting configuratie ontbreekt");
if (environment === "production" && process.env.NEXT_PUBLIC_SITE_URL !== "https://www.voltvroom.nl") {
  unsafe.push("Production NEXT_PUBLIC_SITE_URL moet https://www.voltvroom.nl zijn");
}

const result = {
  ready: missing.length === 0 && unsafe.length === 0,
  environment,
  firebaseClientConfigured,
  firebaseAdminConfigured,
  missing,
  unsafe,
  checkedAt: new Date().toISOString(),
};
console.log(JSON.stringify(result, null, 2));
if (!result.ready) process.exitCode = 1;
