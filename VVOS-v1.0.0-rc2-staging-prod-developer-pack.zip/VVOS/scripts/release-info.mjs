import { execFileSync } from "node:child_process";
import fs from "node:fs";

function git(...args) {
  try { return execFileSync("git", args, { encoding: "utf8" }).trim(); }
  catch { return "unavailable"; }
}

const pkg = JSON.parse(fs.readFileSync("package.json", "utf8"));
console.log(JSON.stringify({
  name: pkg.name,
  version: pkg.version,
  commit: git("rev-parse", "HEAD"),
  branch: git("branch", "--show-current"),
  generatedAt: new Date().toISOString(),
}, null, 2));
