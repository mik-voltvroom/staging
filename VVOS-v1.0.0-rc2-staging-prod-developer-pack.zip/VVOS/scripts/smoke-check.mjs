const baseUrl = (process.env.SMOKE_URL || process.argv[2] || "").replace(/\/$/, "");
if (!baseUrl) {
  console.error("Gebruik: SMOKE_URL=https://... npm run smoke");
  process.exit(2);
}

const checks = [
  { path: "/", kind: "html" },
  { path: "/api/health", kind: "json" },
];

let failed = false;
for (const check of checks) {
  const started = Date.now();
  try {
    const response = await fetch(`${baseUrl}${check.path}`, { redirect: "follow" });
    const elapsed = Date.now() - started;
    if (!response.ok) {
      failed = true;
      console.error(`FAIL ${check.path}: HTTP ${response.status} (${elapsed}ms)`);
      continue;
    }
    if (check.kind === "json") {
      const data = await response.json();
      if (data.status !== "ok") {
        failed = true;
        console.error(`FAIL ${check.path}: status=${data.status}`);
        continue;
      }
    }
    console.log(`OK   ${check.path} (${elapsed}ms)`);
  } catch (error) {
    failed = true;
    console.error(`FAIL ${check.path}: ${error instanceof Error ? error.message : String(error)}`);
  }
}

if (failed) process.exit(1);
