import { NextResponse } from "next/server";
import type { IntegrationStatus } from "@/types";
import { authorizeApi } from "@/lib/auth/api";
import { isFirebaseAdminConfigured, isFirebaseClientConfigured } from "@/lib/config";

export async function GET(request: Request) {
  const auth = await authorizeApi(request, "integrations.read");
  if (auth.response) return auth.response;
  const items: IntegrationStatus[] = [
    { key: "firebase", label: "Firebase", configured: isFirebaseClientConfigured && isFirebaseAdminConfigured, mode: process.env.VVOS_DATA_MODE === "firebase" ? "live" : "demo", detail: "Authenticatie, Firestore en Storage" },
    { key: "rdw", label: "RDW voertuigdata", configured: Boolean(process.env.RDW_API_BASE_URL), mode: process.env.RDW_API_BASE_URL ? "live" : "demo", detail: "Kenteken- en voertuigverrijking" },
    { key: "vwe", label: "VWE voorraadimport", configured: Boolean(process.env.VWE_WEBHOOK_SECRET), mode: process.env.VWE_WEBHOOK_SECRET ? "live" : "demo", detail: "Webhook voor centrale voorraad" },
    { key: "merchant", label: "Google Merchant Center", configured: Boolean(process.env.GOOGLE_MERCHANT_ID && process.env.GOOGLE_MERCHANT_DATASOURCE), mode: process.env.GOOGLE_MERCHANT_ID ? "live" : "demo", detail: "Vehicle feed en synchronisatie" },
    { key: "whatsapp", label: "WhatsApp Business", configured: Boolean(process.env.WHATSAPP_API_URL && process.env.WHATSAPP_TOKEN), mode: process.env.WHATSAPP_API_URL ? "live" : "disabled", detail: "Leadopvolging en afspraken" },
    { key: "email", label: "E-mail", configured: Boolean(process.env.EMAIL_API_URL && process.env.EMAIL_API_KEY), mode: process.env.EMAIL_API_URL ? "live" : "disabled", detail: "Transacties en nurture flows" },
  ];
  return NextResponse.json(items);
}
